package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;
import com.java.transport.model.Bookings;
public interface BookingsDao {
	List<Bookings> showBookingsDao() throws ClassNotFoundException,SQLException;
	Bookings searchBookingsDao(int BookingID) throws ClassNotFoundException, SQLException;
    String addBookingsDao(Bookings Bookings) throws ClassNotFoundException, SQLException;   
    String updateBookingsDao(Bookings Bookings) throws ClassNotFoundException, SQLException;
    String deleteBookingsDao(int BookingID ) throws ClassNotFoundException,SQLException;

}
