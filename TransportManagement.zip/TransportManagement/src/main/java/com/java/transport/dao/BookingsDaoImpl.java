package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.java.transport.model.Bookings;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;

public class BookingsDaoImpl implements BookingsDao {
	Connection connection;
	PreparedStatement pst;
	@Override
	public List<Bookings> showBookingsDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Bookings";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Bookings> bookingsList = new ArrayList<Bookings>();
		Bookings bookings = null;
		while(rs.next()) {
			bookings = new Bookings();
			bookings.setBookingID(rs.getInt("bookingID"));
			bookings.setTripID(rs.getInt("tripID"));
			bookings.setPassengerID(rs.getInt("passengerID"));
			bookings.setBookingDate(rs.getTimestamp("bookingdate"));
			bookings.setStatus(rs.getString("status"));	
			bookingsList.add(bookings);
		}
		return bookingsList;
		
		
	}

	@Override
	public Bookings searchBookingsDao(int BookingID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Bookings where BookingID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,BookingID);
		ResultSet rs = pst.executeQuery();
		Bookings bookings = null;
		if (rs.next()) {
			bookings = new Bookings();
			bookings.setBookingID(rs.getInt("bookingID"));
			bookings.setTripID(rs.getInt("tripID"));
			bookings.setPassengerID(rs.getInt("passengerID"));
			bookings.setBookingDate(rs.getTimestamp("bookingdate"));
			bookings.setStatus(rs.getString("status"));							
		}
		return bookings;
		
	}

	@Override
	public String addBookingsDao(Bookings Bookings) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Bookings(BookingID,tripID,passengerID,bookingdate,Status) values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, Bookings.getBookingID());
		pst.setInt(2, Bookings.getTripID());
		pst.setInt(3, Bookings.getPassengerID());    
        pst.setTimestamp(4, Bookings.getBookingDate());
		pst.setString(5, Bookings.getStatus());
		pst.executeUpdate();
		return "Bookings Record Inserted...";
		
	}

	@Override
	public String updateBookingsDao(Bookings Bookings) throws ClassNotFoundException, SQLException {
		Bookings BookingsFound = searchBookingsDao(Bookings.getBookingID());
		if(BookingsFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Bookings set TripID=?,PassengerID=?,bookingdate=?,Status=? where BookingId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, Bookings.getBookingID());
			pst.setInt(2, Bookings.getTripID());
			pst.setInt(3, Bookings.getPassengerID());    
	        pst.setTimestamp(4, Bookings.getBookingDate());
			pst.setString(5, Bookings.getStatus());
			pst.executeUpdate();
			return "Bookings Record Inserted...";			
		}		
		return "Bookings Record not Insert...";
		
		
	}

	@Override
	public String deleteBookingsDao(int BookingID) throws ClassNotFoundException, SQLException {
		Bookings bookingsFound = searchBookingsDao(BookingID);
		if(bookingsFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Bookings Where BookingID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,BookingID);
			pst.executeUpdate();
			return "Booking Record Deleted...";
			
		}
		return "Booking record not found...";
		
	}


}
