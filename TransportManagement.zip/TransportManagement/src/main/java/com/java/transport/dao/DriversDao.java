package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.transport.model.Drivers;

public interface DriversDao {
	List<Drivers> showDriversDao() throws ClassNotFoundException,SQLException;
	Drivers searchDriversDao(int DriverID) throws ClassNotFoundException, SQLException;
    String addDriversDao(Drivers Drivers) throws ClassNotFoundException, SQLException;   
    String updateDriversDao(Drivers Drivers) throws ClassNotFoundException, SQLException;
    String deleteDriversDao(int DriverID ) throws ClassNotFoundException,SQLException;

}
