package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.transport.model.Bookings;
import com.java.transport.model.Drivers;
import com.java.transport.model.Vehicles;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;

public class DriversDaoImpl implements DriversDao {
	Connection connection;
	PreparedStatement pst;	

	@Override
	public List<Drivers> showDriversDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Drivers";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Drivers> driversList = new ArrayList<Drivers>();
		Drivers drivers = null;
		while(rs.next()) {
			drivers = new Drivers();
			drivers.setDriverID(rs.getInt("DriverID"));
			drivers.setTripID(rs.getInt("TripID"));
			drivers.setVehicleID(rs.getInt("VehicleID"));
			drivers.setType(rs.getString("type"));
			driversList.add(drivers);
		}
		return driversList;
		
	}

	@Override
	public Drivers searchDriversDao(int DriverID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Drivers where DriverID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,DriverID);
		ResultSet rs = pst.executeQuery();
		Drivers drivers = null;
		if (rs.next()) {
			drivers = new Drivers();
			drivers.setDriverID(rs.getInt("DriverID"));
			drivers.setTripID(rs.getInt("TripID"));
			drivers.setVehicleID(rs.getInt("VehicleID"));
			drivers.setType(rs.getString("type"));
									
		}
		return drivers;
	}

	@Override
	public String addDriversDao(Drivers Drivers) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Vehicles(DriverID,TripID,VehicleID,Type) values(?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, Drivers.getDriverID());
		pst.setInt(2, Drivers.getTripID());
		pst.setInt(3, Drivers.getVehicleID());
		pst.setString(4, Drivers.getType());		
		pst.executeUpdate();
		return "Driver Record Inserted...";
		
	}

	@Override
	public String updateDriversDao(Drivers Drivers) throws ClassNotFoundException, SQLException {
		Drivers driversFound = searchDriversDao(Drivers.getDriverID());
		if(driversFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Drivers set TripID=?,VehicleID=?,Type=? where DriverId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, Drivers.getDriverID());
			pst.setInt(2, Drivers.getTripID());
			pst.setInt(3, Drivers.getVehicleID());
			pst.setString(4, Drivers.getType());
			pst.executeUpdate();
			return "Drivers Record Updated...";			
		}		
		return "Drivers Record not found...";
		
		
	}

	@Override
	public String deleteDriversDao(int DriverID) throws ClassNotFoundException, SQLException {
		Drivers driversFound = searchDriversDao(DriverID);
		if(driversFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Drivers Where DriverID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,DriverID);
			pst.executeUpdate();
			return "Drivers Record Deleted...";
			
		}
		return "Drivers record not found...";
		
	}
		
	}


