package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.transport.model.Passengers;

public interface PassengersDao {
	List<Passengers> showPassengersDao() throws ClassNotFoundException,SQLException;
	Passengers searchPassengersDao(int PassengerID) throws ClassNotFoundException, SQLException;
    String addPassengersDao(Passengers passengers) throws ClassNotFoundException, SQLException; 
    String updatePassengersDao(Passengers passengers) throws ClassNotFoundException, SQLException;
    String deletePassengersDao(int passengerID ) throws ClassNotFoundException,SQLException;

}
