package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.transport.model.Passengers;
import com.java.transport.model.Routes;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;

public class PassengersDaoImpl implements PassengersDao {
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Passengers> showPassengersDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Passengers";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Passengers> passengersList = new ArrayList<Passengers>();
		Passengers passengers = null;
		while(rs.next()) {
			passengers = new Passengers();
			passengers.setPassengerID(rs.getInt("passengerID"));
			passengers.setFirstName(rs.getString("firstname"));
			passengers.setGender(rs.getString("gender"));
			passengers.setAge(rs.getInt("age"));
			passengers.setEmail(rs.getString("email"));
			passengers.setPhonenumber(rs.getString("phonenumber"));			
			passengersList.add(passengers);
		}
		return passengersList;
		
		
	}

	@Override
	public Passengers searchPassengersDao(int PassengerID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Passengers where PassengerID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,PassengerID);
		ResultSet rs = pst.executeQuery();
		Passengers passengers = null;
		if (rs.next()) {
			passengers = new Passengers();
			passengers.setPassengerID(rs.getInt("passengerID"));
			passengers.setFirstName(rs.getString("firstname"));
			passengers.setGender(rs.getString("gender"));
			passengers.setAge(rs.getInt("age"));
			passengers.setEmail(rs.getString("email"));
			passengers.setPhonenumber(rs.getString("phonenumber"));			
		}
		return passengers;
	}

	@Override
	public String addPassengersDao(Passengers passengers) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Passengers(PassengerID,FirstName,Gender,Age,Email,Phonenumber) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, passengers.getPassengerID());
		pst.setString(2, passengers.getFirstName());
		pst.setString(3, passengers.getGender());
		pst.setDouble(4, passengers.getAge());
		pst.setString(5, passengers.getEmail());
		pst.setString(6, passengers.getPhonenumber());
		pst.executeUpdate();
		return "Passengers Record Inserted...";
		
	}

	@Override
	public String updatePassengersDao(Passengers passengers) throws ClassNotFoundException, SQLException {
		Passengers PassengersFound = searchPassengersDao(passengers.getPassengerID());
		if(PassengersFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Passengers set FirstName=?,Gender=?,Age=?,Email=?,Phonenumber=? where PassengerId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, passengers.getPassengerID());
			pst.setString(2, passengers.getFirstName());
			pst.setString(3, passengers.getGender());
			pst.setDouble(4, passengers.getAge());
			pst.setString(5, passengers.getEmail());
			pst.setString(6, passengers.getPhonenumber());
			pst.executeUpdate();
			return "Passengers Record Updated...";			
		}		
		return "Passengers Record not found...";
		
		
	}

	@Override
	public String deletePassengersDao(int passengerID) throws ClassNotFoundException, SQLException {
		Passengers passengersFound = searchPassengersDao(passengerID);
		if(passengersFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Passengers Where PassengerID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,passengerID);
			pst.executeUpdate();
			return "Passenger Record Deleted...";
			
		}
		return "Passenger record not found...";
		
	}
	}


