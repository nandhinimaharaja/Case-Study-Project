package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.transport.model.Routes;

public interface RoutesDao {
	List<Routes> showRoutesDao() throws ClassNotFoundException,SQLException;
	Routes searchRoutesDao(int RouteID) throws ClassNotFoundException, SQLException;
    String addRoutesDao(Routes routes) throws ClassNotFoundException, SQLException; 
    String updateRoutesDao(Routes routes) throws ClassNotFoundException, SQLException;
    String deleteRoutesDao(int routeID ) throws ClassNotFoundException,SQLException;

}
