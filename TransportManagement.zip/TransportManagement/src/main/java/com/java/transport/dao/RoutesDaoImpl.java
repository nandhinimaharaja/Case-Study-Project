package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.transport.model.Routes;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;

public class RoutesDaoImpl implements RoutesDao{
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Routes> showRoutesDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Routes";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Routes> routesList = new ArrayList<Routes>();
		Routes routes = null;
		while(rs.next()) {
			routes = new Routes();
			routes.setRouteID(rs.getInt("routeID"));
			routes.setStartdestination(rs.getString("startdestination"));
			routes.setEnddestination(rs.getString("enddestination"));
			routes.setDistance(rs.getDouble("distance"));
			routesList.add(routes);
		}
		return routesList;
		
	}

	@Override
	public Routes searchRoutesDao(int RouteID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Routes where RouteID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,RouteID);
		ResultSet rs = pst.executeQuery();
		Routes routes = null;
		if (rs.next()) {
			routes = new Routes();
			routes.setRouteID(rs.getInt("RouteID"));
			routes.setStartdestination(rs.getString("startdestination"));
			routes.setEnddestination(rs.getString("enddestination"));
			routes.setDistance(rs.getDouble("distance"));
			
		}
		return routes;
		
	}

	@Override
	public String addRoutesDao(Routes routes) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Routes(RouteID,Startdestination,Enddestination,Distance) values(?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, routes.getRouteID());
		pst.setString(2, routes.getStartdestination());
		pst.setString(3, routes.getEnddestination());
		pst.setDouble(4, routes.getDistance());
		pst.executeUpdate();
		return "Route Record Inserted...";
	}

	@Override
	public String updateRoutesDao(Routes routes) throws ClassNotFoundException, SQLException {
		Routes routesFound = searchRoutesDao(routes.getRouteID());
		if(routesFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Routes set Startdestination=?,Enddestination=?,Distance=? where RouteId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, routes.getRouteID());
			pst.setString(2, routes.getStartdestination());
			pst.setString(3, routes.getEnddestination());
			pst.setDouble(4, routes.getDistance());
			pst.executeUpdate();
			return "Routes Record Updated...";			
		}		
		return "Routes Record not found...";
		
	}

	@Override
	public String deleteRoutesDao(int routeID) throws ClassNotFoundException, SQLException {
		Routes routesFound = searchRoutesDao(routeID);
		if(routesFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Routes Where RouteID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,routeID);
			pst.executeUpdate();
			return "Route Record Deleted...";
			
		}
		return "Route record not found...";
		
	}
		
	}


