package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.transport.model.Trips;

public interface TripsDao {
	List<Trips> showTripsDao() throws ClassNotFoundException,SQLException;
	Trips searchTripsDao(int TripID) throws ClassNotFoundException, SQLException;
    String addTripsDao(Trips trips) throws ClassNotFoundException, SQLException; 
    String updateTripsDao(Trips trips) throws ClassNotFoundException, SQLException;
    String deleteTripsDao(int tripID ) throws ClassNotFoundException,SQLException;

}
