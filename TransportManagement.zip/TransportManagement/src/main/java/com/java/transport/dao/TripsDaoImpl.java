package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.java.transport.model.Trips;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;

public class TripsDaoImpl implements TripsDao {
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Trips> showTripsDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Trips";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Trips> tripsList = new ArrayList<Trips>();
		Trips trips = null;
		while(rs.next()) {
			trips = new Trips();
			trips.setTripID(rs.getInt("tripID"));
			trips.setVehicleID(rs.getInt("vehicleID"));
			trips.setRouteID(rs.getInt("routeID"));
			trips.setDepaturedate(rs.getDate("departuredate"));
			trips.setArrivaldate(rs.getDate("arrivaldate"));
			trips.setStatus(rs.getString("status"));
			trips.setTripType(rs.getString("triptype"));
			trips.setMaxpassengers(rs.getInt("maxpassengers"));	
			tripsList.add(trips);
		}
		return tripsList;
		
	}

	@Override
	public Trips searchTripsDao(int TripID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Trips where TripID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,TripID);
		ResultSet rs = pst.executeQuery();
		Trips trips = null;
		if (rs.next()) {
			trips = new Trips();
			trips.setTripID(rs.getInt("tripID"));
			trips.setVehicleID(rs.getInt("vehicleID"));
			trips.setRouteID(rs.getInt("routeID"));
			trips.setDepaturedate(rs.getDate("departuredate"));
			trips.setArrivaldate(rs.getDate("arrivaldate"));
			trips.setStatus(rs.getString("status"));
			trips.setTripType(rs.getString("triptype"));
			trips.setMaxpassengers(rs.getInt("maxpassengers"));	
		}
		return trips;
		
	}

	@Override
	public String addTripsDao(Trips trips) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Trips(TripID,VehicleID,RouteID,DepartureDate,ArrivalDate,Status,TripType,MaxPassengers) values(?,?,?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, trips.getTripID());
		pst.setInt(2, trips.getVehicleID());
		pst.setInt(3, trips.getRouteID());
		pst.setDate(4, trips.getDepaturedate());
		pst.setDate(5, trips.getArrivaldate());
		pst.setString(6, trips.getStatus());
		pst.setString(7, trips.getTripType());
		pst.setInt(8, trips.getMaxpassengers());
		pst.executeUpdate();
		
		return "Trips Record Inserted...";
		
	}

	@Override
	public String updateTripsDao(Trips trips) throws ClassNotFoundException, SQLException {
		Trips TripsFound = searchTripsDao(trips.getTripID());
		if(TripsFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Trips set VehicleID=?,RouteID=?,Departuredate=?,Arrivaldate=?,Status=?,TripType=?,Maxpassengers=? where TripId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, trips.getTripID());
			pst.setInt(2, trips.getVehicleID());
			pst.setInt(3, trips.getRouteID());
			pst.setDate(4, trips.getDepaturedate());
			pst.setDate(5, trips.getArrivaldate());
			pst.setString(6, trips.getStatus());
			pst.setString(7, trips.getTripType());
			pst.setInt(8, trips.getMaxpassengers());
			pst.executeUpdate();
			
			return "Trips Record Updated...";			
		}		
		return "Trips Record not found...";
		
	}

	@Override
	public String deleteTripsDao(int tripID) throws ClassNotFoundException, SQLException {
		Trips tripsFound = searchTripsDao(tripID);
		if(tripsFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Trips Where TripID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,tripID);
			pst.executeUpdate();
			return "Trip Record Deleted...";
			
		}
		return "Trip record not found...";
		
	}

}
