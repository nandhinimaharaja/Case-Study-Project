package com.java.transport.dao;

import java.sql.SQLException;
import java.util.List;
import com.java.transport.model.Vehicles;

public interface VehiclesDao {
	List<Vehicles> showVehiclesDao() throws ClassNotFoundException,SQLException;
	Vehicles searchVehiclesDao(int vehicleID) throws ClassNotFoundException, SQLException;
    String addVehiclesDao(Vehicles vehicles) throws ClassNotFoundException, SQLException; 
    String updateVehiclesDao(Vehicles vehicles) throws ClassNotFoundException, SQLException;
    String deleteVehiclesDao(int vehicleID ) throws ClassNotFoundException,SQLException;

}
