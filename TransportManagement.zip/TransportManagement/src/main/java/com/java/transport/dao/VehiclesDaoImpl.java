package com.java.transport.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.java.transport.util.DBConnUtil;
import com.java.transport.util.DBPropertiesUtil;
import com.java.transport.model.Vehicles;

public class VehiclesDaoImpl implements VehiclesDao{
	Connection connection;
	PreparedStatement pst;	

	@Override
	public List<Vehicles> showVehiclesDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Vehicles";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Vehicles> vehiclesList = new ArrayList<Vehicles>();
		Vehicles vehicles = null;
		while(rs.next()) {
			vehicles = new Vehicles();
			vehicles.setVehicleID(rs.getInt("vehicleID"));
			vehicles.setModel(rs.getString("model"));
			vehicles.setCapacity(rs.getDouble("capacity"));
			vehicles.setType(rs.getString("type"));
			vehicles.setStatus(rs.getString("status"));
			vehiclesList.add(vehicles);
		}
		return vehiclesList;
       }

	@Override
	public Vehicles searchVehiclesDao(int vehicleID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd = "select * from Vehicles where VehicleID = ?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,vehicleID);
		ResultSet rs = pst.executeQuery();
		Vehicles vehicles = null;
		if (rs.next()) {
			vehicles = new Vehicles();
			vehicles.setVehicleID(rs.getInt("vehicleID"));
			vehicles.setModel(rs.getString("model"));
			vehicles.setCapacity(rs.getDouble("capacity"));
			vehicles.setType(rs.getString("type"));
			vehicles.setStatus(rs.getString("status"));
		}
		return vehicles;
	}

	@Override
	public String addVehiclesDao(Vehicles vehicles) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertiesUtil.getConnectionString("db");
		connection = DBConnUtil.GetConnection(connStr);
		String cmd="Insert into Vehicles(VehicleID,Model,Capacity,Type,Status) values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, vehicles.getVehicleID());
		pst.setString(2, vehicles.getModel());
		pst.setDouble(3, vehicles.getCapacity());
		pst.setString(4, vehicles.getType());
		pst.setString(5, vehicles.getStatus());
		
		pst.executeUpdate();
		return "Vehicle Record Inserted...";
		
	}

	@Override
	public String updateVehiclesDao(Vehicles vehicles) throws ClassNotFoundException, SQLException {
		Vehicles vehiclesFound = searchVehiclesDao(vehicles.getVehicleID());
		if(vehiclesFound!=null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Update Vehicles set Model=?,Capacity=?,Type=?,Status=? where VehicleId=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1, vehicles.getVehicleID());
			pst.setString(2, vehicles.getModel());
			pst.setDouble(3, vehicles.getCapacity());
			pst.setString(4, vehicles.getType());
			pst.setString(5, vehicles.getStatus());
			pst.executeUpdate();
			return "Vehicles Record Updated...";			
		}		
		return "Vehicles Record not found...";
		
	}

	@Override
	public String deleteVehiclesDao(int vehicleID) throws ClassNotFoundException, SQLException {
		Vehicles vehiclesFound = searchVehiclesDao(vehicleID);
		if(vehiclesFound != null) {
			String connStr = DBPropertiesUtil.getConnectionString("db");
			connection = DBConnUtil.GetConnection(connStr);
			String cmd = "Delete From Vehicles Where VehicleID=?";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,vehicleID);
			pst.executeUpdate();
			return "Vehicle Record Deleted...";
			
		}
		return "Vehicle record not found...";
		
	}
}



