package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.DriversDao;
import com.java.transport.dao.DriversDaoImpl;
import com.java.transport.model.Drivers;

public class AllocateDriver {
	public static void main(String[] args) {
		Drivers drivers = new Drivers();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Driver ID ");
		drivers.setDriverID(sc.nextInt());
		System.out.println("Enter Trip ID ");
		drivers.setTripID(sc.nextInt());
		System.out.println("Enter Vehicle ID");
		drivers.setVehicleID(sc.nextInt());
		System.out.println("Enter Type ");
		drivers.setType(sc.next());	
		DriversDao dao = new DriversDaoImpl();
		try {
			System.out.println(dao.addDriversDao(drivers));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}



}
