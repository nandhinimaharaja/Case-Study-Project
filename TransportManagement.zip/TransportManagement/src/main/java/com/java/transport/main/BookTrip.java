
	package com.java.transport.main;

	import java.sql.SQLException;
	import java.sql.Date;
	import java.text.ParseException;
	import java.text.SimpleDateFormat;
	import java.util.Scanner;
	import com.java.transport.dao.TripsDao;
	import com.java.transport.dao.TripsDaoImpl;
	import com.java.transport.model.Trips;

	public class BookTrip {
	    public static void main(String[] args) {
	        Trips trips = new Trips();
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.println("Enter Trip ID:");
	        trips.setTripID(sc.nextInt());
	        
	        System.out.println("Enter Vehicle ID:");
	        trips.setVehicleID(sc.nextInt());
	        
	        System.out.println("Enter Route ID:");
	        trips.setRouteID(sc.nextInt());
	        
	        sc.nextLine(); // Consume newline character
	        
	        System.out.println("Enter Departure Date (YYYY-MM-DD HH:MM:SS):");
	        String departureDateStr = sc.nextLine();
	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	            java.util.Date departureDate = dateFormat.parse(departureDateStr);
	            Date sqlDepartureDate = new Date(departureDate.getTime());
	            trips.setDepaturedate(sqlDepartureDate); // Use java.sql.Date
	        } catch (ParseException e) {
	            System.out.println("Invalid date format. Please enter date in format 'YYYY-MM-DD HH:MM:SS'.");
	            return;
	        }
	        
	        System.out.println("Enter Arrival Date (YYYY-MM-DD HH:MM:SS):");
	        String arrivalDateStr = sc.nextLine();
	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	            java.util.Date arrivalDate = dateFormat.parse(arrivalDateStr);
	            Date sqlArrivalDate = new Date(arrivalDate.getTime());
	            trips.setArrivaldate(sqlArrivalDate); // Use java.sql.Date
	        } catch (ParseException e) {
	            System.out.println("Invalid date format. Please enter date in format 'YYYY-MM-DD HH:MM:SS'.");
	            return;
	        }

	        System.out.println("Enter Status:");
	        trips.setStatus(sc.next());
	        
	        System.out.println("Enter Trip Type:");
	        trips.setTripType(sc.next());
	        
	        System.out.println("Enter Max Passengers:");
	        trips.setMaxpassengers(sc.nextInt());
	        
	        TripsDao dao = new TripsDaoImpl();
	        try {
	            System.out.println(dao.addTripsDao(trips));
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        }
	    }
	

	}
