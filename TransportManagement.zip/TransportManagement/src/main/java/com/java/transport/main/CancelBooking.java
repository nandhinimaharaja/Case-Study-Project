package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.BookingsDao;
import com.java.transport.dao.BookingsDaoImpl;

public class CancelBooking {
	public static void main(String[] args) {
		int BookingID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter passenger ID ");
		BookingID=sc.nextInt();
		BookingsDao dao = new BookingsDaoImpl();
		try {
			System.out.println(dao.deleteBookingsDao(BookingID));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
