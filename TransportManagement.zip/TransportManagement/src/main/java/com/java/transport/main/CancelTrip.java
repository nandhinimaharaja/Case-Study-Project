package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.TripsDao;
import com.java.transport.dao.TripsDaoImpl;

public class CancelTrip {
	public static void main(String[] args) {
		int TripID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter trip ID ");
		TripID=sc.nextInt();
		TripsDao dao = new TripsDaoImpl();
		try {
			System.out.println(dao.deleteTripsDao(TripID));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
