package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.VehiclesDao;
import com.java.transport.dao.VehiclesDaoImpl;

public class DeleteVehicle {
	public static void main(String[] args) {
		int VehicleID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter vehicle ID ");
		VehicleID=sc.nextInt();
		VehiclesDao dao = new VehiclesDaoImpl();
		try {
			System.out.println(dao.deleteVehiclesDao(VehicleID));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}