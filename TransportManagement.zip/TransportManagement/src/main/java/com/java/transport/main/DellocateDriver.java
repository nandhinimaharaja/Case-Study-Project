package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.DriversDao;
import com.java.transport.dao.DriversDaoImpl;

public class DellocateDriver {
	public static void main(String[] args) {
		int DriverID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Driver ID ");
		DriverID=sc.nextInt();
		DriversDao dao = new DriversDaoImpl();
		try {
			System.out.println(dao.deleteDriversDao(DriverID));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
