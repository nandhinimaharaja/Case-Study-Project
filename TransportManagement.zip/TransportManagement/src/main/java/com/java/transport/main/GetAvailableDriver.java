package com.java.transport.main;

import java.sql.SQLException;
import java.util.List;

import com.java.transport.model.Drivers;
import com.java.transport.dao.DriversDao;
import com.java.transport.dao.DriversDaoImpl;

public class GetAvailableDriver {
	public static void main(String[] args) {
		DriversDao dao = new DriversDaoImpl();
		try {
			List<Drivers> driversList = dao.showDriversDao();
			for (Drivers drivers : driversList) {
				System.out.println(drivers);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
