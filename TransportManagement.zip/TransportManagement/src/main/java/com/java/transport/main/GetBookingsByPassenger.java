package com.java.transport.main;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import com.java.transport.dao.BookingsDao;
import com.java.transport.dao.BookingsDaoImpl;
import com.java.transport.model.Bookings;

public class GetBookingsByPassenger {
    public static void main(String[] args) {
        Bookings bookings = new Bookings();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Booking ID:");
        bookings.setBookingID(sc.nextInt());

        System.out.println("Enter Trip ID:");
        bookings.setTripID(sc.nextInt());

        System.out.println("Enter Passenger ID:");
        bookings.setPassengerID(sc.nextInt());

        sc.nextLine(); // Consume newline character

        System.out.println("Enter a timestamp (YYYY-MM-DD HH:MM:SS):");
        String timestampString = sc.nextLine();

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            java.util.Date parsedDate = dateFormat.parse(timestampString);
            java.sql.Timestamp bookingTimestamp = new java.sql.Timestamp(parsedDate.getTime());
            bookings.setBookingDate(bookingTimestamp);
        } catch (ParseException e) {
            System.out.println("Invalid timestamp format. Please enter timestamp in format 'YYYY-MM-DD HH:MM:SS'.");
            return;
        }

        System.out.println("Enter Status:");
        bookings.setStatus(sc.next());

        BookingsDao dao = new BookingsDaoImpl();
        try {
            System.out.println(dao.addBookingsDao(bookings));
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
