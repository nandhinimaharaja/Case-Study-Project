package com.java.transport.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.transport.dao.VehiclesDao;
import com.java.transport.dao.VehiclesDaoImpl;
import com.java.transport.model.Vehicles;

public class UpdateVehicle{
	public static void main(String[] args) {
		Vehicles vehicles = new Vehicles();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Vehicle ID ");
		vehicles.setVehicleID(sc.nextInt());
		System.out.println("Enter Model ");
		vehicles.setModel(sc.next());
		System.out.println("Enter Capacity");
		vehicles.setCapacity(sc.nextDouble());
		System.out.println("Enter Type ");
		vehicles.setType(sc.next());
		System.out.println("Enter Status  ");
		vehicles.setStatus(sc.next());		
		VehiclesDao dao = new VehiclesDaoImpl();
		try {
			System.out.println(dao.updateVehiclesDao(vehicles));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}

}
