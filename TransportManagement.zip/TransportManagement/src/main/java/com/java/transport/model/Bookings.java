package com.java.transport.model;

import java.sql.Timestamp;
import java.util.Objects;

public class Bookings {
    private int bookingID;
    private int tripID;
    private int passengerID;
    private Timestamp BookingDate;
    private String Status;

    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public int getTripID() {
        return tripID;
    }

    public void setTripID(int tripID) {
        this.tripID = tripID;
    }

    public int getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }

    public Timestamp getBookingDate() {
        return BookingDate;
    }

    public void setBookingDate(Timestamp bookingDate) {
        BookingDate = bookingDate;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public Bookings(int bookingID, int tripID, int passengerID, Timestamp bookingDate, String status) {
        super();
        this.bookingID = bookingID;
        this.tripID = tripID;
        this.passengerID = passengerID;
        BookingDate = bookingDate;
        Status = status;
    }

    public Bookings() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
        return "Bookings [bookingID=" + bookingID + ", tripID=" + tripID + ", passengerID=" + passengerID
                + ", BookingDate=" + BookingDate + ", Status=" + Status + "]";
    }

    @Override
    public int hashCode() {
        return Objects.hash(BookingDate, Status, bookingID, passengerID, tripID);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Bookings bookings = (Bookings) obj;
        return bookingID == bookings.bookingID &&
                tripID == bookings.tripID &&
                passengerID == bookings.passengerID &&
                Objects.equals(BookingDate, bookings.BookingDate) &&
                Objects.equals(Status, bookings.Status);
    }
}
