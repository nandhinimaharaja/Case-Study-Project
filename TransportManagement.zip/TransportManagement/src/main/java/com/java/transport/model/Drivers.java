package com.java.transport.model;

import java.util.Objects;

public class Drivers {
	private int DriverID;
	private int TripID;
	private int VehicleID;
	private String Type;
	public int getDriverID() {
		return DriverID;
	}
	public void setDriverID(int driverID) {
		DriverID = driverID;
	}
	public int getTripID() {
		return TripID;
	}
	public void setTripID(int tripID) {
		TripID = tripID;
	}
	public int getVehicleID() {
		return VehicleID;
	}
	public void setVehicleID(int vehicleID) {
		VehicleID = vehicleID;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public Drivers(int driverID, int tripID, int vehicleID, String type) {
		super();
		DriverID = driverID;
		TripID = tripID;
		VehicleID = vehicleID;
		Type = type;
	}
	public Drivers() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Drivers [DriverID=" + DriverID + ", TripID=" + TripID + ", VehicleID=" + VehicleID + ", Type=" + Type
				+ "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(DriverID, TripID, Type, VehicleID);
	}
	@Override
	public boolean equals(Object obj) {
		Drivers drivers = (Drivers)obj;
		if(drivers.getDriverID()==DriverID && drivers.getTripID()==TripID && drivers.getVehicleID()==VehicleID && drivers.getType()==Type) {
			return true;
		}
		return false;
		
	}
	

}
