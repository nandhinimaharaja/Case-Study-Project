package com.java.transport.model;

import java.util.Objects;

public class Passengers {
	private int passengerID;
	private String FirstName;
	private String gender;
	private int age;
	private String email;
	private String phonenumber;

	public int getPassengerID() {
		return passengerID;
	}

	public void setPassengerID(int passengerID) {
		this.passengerID = passengerID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Passengers(int passengerID, String firstName, String gender, int age, String email, String phonenumber) {
		super();
		this.passengerID = passengerID;
		FirstName = firstName;
		this.gender = gender;
		this.age = age;
		this.email = email;
		this.phonenumber = phonenumber;
	}

	public Passengers() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Passengers [passengerID=" + passengerID + ", FirstName=" + FirstName + ", gender=" + gender + ", age="
				+ age + ",email=" + email + ",phonenumber=" + phonenumber + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(FirstName, age, email, gender, passengerID, phonenumber);
	}

	@Override
	public boolean equals(Object obj) {
		Passengers passengers = (Passengers)obj;
		if(passengers.getPassengerID()==passengerID && passengers.getFirstName()==FirstName && passengers.getGender()==gender && passengers.getAge()==age && passengers.getEmail()==email && passengers.getPhonenumber()==phonenumber) {
			return true;
		}
		return false;
		
	}
	

}
