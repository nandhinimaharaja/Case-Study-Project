package com.java.transport.model;

import java.util.Objects;

public class Routes {
	private int routeID;
	private String startdestination;
	private String enddestination;
    private double distance;
	public int getRouteID() {
		return routeID;
	}
	public void setRouteID(int routeID) {
		this.routeID = routeID;
	}
	public String getStartdestination() {
		return startdestination;
	}
	public void setStartdestination(String startdestination) {
		this.startdestination = startdestination;
	}
	public String getEnddestination() {
		return enddestination;
	}
	public void setEnddestination(String enddestination) {
		this.enddestination = enddestination;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public Routes(int routeID, String startdestination, String enddestination, double distance) {
		super();
		this.routeID = routeID;
		this.startdestination = startdestination;
		this.enddestination = enddestination;
		this.distance = distance;
	}
	public Routes() {
		
	}
	@Override
	public String toString() {
		return "Routes [routeID=" + routeID + ", startdestination=" + startdestination + ", enddestination="
				+ enddestination + ", distance=" + distance + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(distance, enddestination, routeID, startdestination);
	}
	@Override
	public boolean equals(Object obj) {
		Routes routes = (Routes)obj;
		if(routes.getRouteID()==routeID && routes.getStartdestination()==startdestination && routes.getEnddestination()==enddestination && routes.getDistance()==distance) {
			return true;
		}
		return false;

    }
}