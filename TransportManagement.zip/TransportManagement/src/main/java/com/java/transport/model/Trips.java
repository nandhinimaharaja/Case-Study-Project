package com.java.transport.model;

import java.sql.Date;
import java.util.Objects;

public class Trips {
	private int tripID;
	private int vehicleID;
	private int routeID;
	private Date depaturedate;
	private Date arrivaldate;
	private String status;
	private String tripType;
	private int maxpassengers;
	public int getTripID() {
		return tripID;
	}
	public void setTripID(int tripID) {
		this.tripID = tripID;
	}
	public int getVehicleID() {
		return vehicleID;
	}
	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}
	public int getRouteID() {
		return routeID;
	}
	public void setRouteID(int routeID) {
		this.routeID = routeID;
	}
	public Date getDepaturedate() {
		return depaturedate;
	}
	public void setDepaturedate(Date depaturedate) {
		this.depaturedate = depaturedate;
	}
	public Date getArrivaldate() {
		return arrivaldate;
	}
	public void setArrivaldate(Date arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public int getMaxpassengers() {
		return maxpassengers;
	}
	public void setMaxpassengers(int maxpassengers) {
		this.maxpassengers = maxpassengers;
	}
	public Trips(int tripID, int vehicleID, int routeID, Date depaturedate, Date arrivaldate, String status,
			String tripType, int maxpassengers) {
		super();
		this.tripID = tripID;
		this.vehicleID = vehicleID;
		this.routeID = routeID;
		this.depaturedate = depaturedate;
		this.arrivaldate = arrivaldate;
		this.status = status;
		this.tripType = tripType;
		this.maxpassengers = maxpassengers;
	}
	public Trips() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Trips [tripID=" + tripID + ", vehicleID=" + vehicleID + ", routeID=" + routeID + ", depaturedate="
				+ depaturedate + ", arrivaldate=" + arrivaldate + ", status=" + status + ", tripType=" + tripType
				+ ", maxpassengers=" + maxpassengers + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(arrivaldate, depaturedate, maxpassengers, routeID, status, tripID, tripType, vehicleID);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Trips trips = (Trips) obj;
		return tripID == trips.tripID && vehicleID == trips.vehicleID && routeID == trips.routeID
				&& maxpassengers == trips.maxpassengers && Objects.equals(depaturedate, trips.depaturedate)
				&& Objects.equals(arrivaldate, trips.arrivaldate) && Objects.equals(status, trips.status)
				&& Objects.equals(tripType, trips.tripType);
		
	}
	
	

}
