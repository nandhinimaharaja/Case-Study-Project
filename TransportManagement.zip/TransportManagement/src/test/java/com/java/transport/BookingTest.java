package com.java.transport;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Bookings;

public class BookingTest {
    
    @Test
    public void testToString() throws ParseException {
        Bookings bookings1 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        String result = "Bookings [bookingID=44, tripID=24, passengerID=4, BookingDate=2024-05-04 10:15:00.0, Status=Completed]";
        assertEquals(result, bookings1.toString());
    }

    @Test
    public void testEquals() throws ParseException {
        Bookings bookings1 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        Bookings bookings2 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        Bookings bookings3 = new Bookings(45, 25, 5, Timestamp.valueOf("2024-05-05 11:16:00"), "Pending");
        assertTrue(bookings1.equals(bookings2));
        assertFalse(bookings1.equals(bookings3));
    }

    @Test
    public void testHashCode() throws ParseException {
        Bookings bookings1 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        Bookings bookings2 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        assertEquals(bookings1.hashCode(), bookings2.hashCode());
    }

    @Test
    public void testGettersAndSetters() throws ParseException {
        Bookings bookings = new Bookings();
        bookings.setBookingID(44);
        bookings.setTripID(24);
        bookings.setPassengerID(4);
        bookings.setBookingDate(Timestamp.valueOf("2024-05-04 10:15:00"));
        bookings.setStatus("Completed");
        assertEquals(44, bookings.getBookingID());
        assertEquals(24, bookings.getTripID());
        assertEquals(4, bookings.getPassengerID());
        assertEquals(Timestamp.valueOf("2024-05-04 10:15:00"), bookings.getBookingDate());
        assertEquals("Completed", bookings.getStatus());
    }

    @Test
    public void testConstructors() throws ParseException {
        Bookings bookings = new Bookings();
        assertNotNull(bookings);
        assertEquals(0, bookings.getBookingID()); // Default value for int
        assertEquals(0, bookings.getTripID()); // Default value for int
        assertEquals(0, bookings.getPassengerID()); // Default value for int
        assertNull(bookings.getBookingDate()); // Default value for Timestamp
        assertNull(bookings.getStatus()); // Default value for String

        Bookings bookings4 = new Bookings(44, 24, 4, Timestamp.valueOf("2024-05-04 10:15:00"), "Completed");
        assertEquals(44, bookings4.getBookingID());
        assertEquals(24, bookings4.getTripID());
        assertEquals(4, bookings4.getPassengerID());
        assertEquals(Timestamp.valueOf("2024-05-04 10:15:00"), bookings4.getBookingDate());
        assertEquals("Completed", bookings4.getStatus());
    }
}
