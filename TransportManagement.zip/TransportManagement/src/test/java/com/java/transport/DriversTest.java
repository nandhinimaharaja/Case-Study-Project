package com.java.transport;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Drivers;

public class DriversTest {
	
@Test

public void testToString() throws ParseException{
	Drivers drivers1 = new Drivers(11, 21, 1, "Car");
	String result = "Drivers [DriverID=11, TripID=21, VehicleID=1, Type=Car]";
	assertEquals(result, drivers1.toString());
	
}

@Test

public void testEquals() throws ParseException{
	Drivers drivers1 = new Drivers(11,21,1,"car");
	Drivers drivers2 = new Drivers(11,21,1,"car");
	Drivers drivers3 = new Drivers(22,21,1,"bus");
	assertTrue(drivers1.equals(drivers2));
	assertFalse(drivers1.equals(drivers3));
	
}

@Test

public void testHashCode() throws ParseException{
	Drivers drivers1 = new Drivers(11,21,1,"car");
	Drivers drivers2 = new Drivers(11,21,1,"car");
	assertEquals(drivers1.hashCode(),drivers2.hashCode());
}
@Test

public void testGettersAndSetters() throws ParseException{
	Drivers drivers = new Drivers();
	drivers.setDriverID(11);
	drivers.setTripID(21);
	drivers.setVehicleID(1);
	drivers.setType("car");
	assertEquals(11,drivers.getDriverID());
	assertEquals(21,drivers.getTripID());
	assertEquals(1,drivers.getVehicleID());
	assertEquals("car",drivers.getType());
}
@Test

public void testConstructors() throws ParseException{
	Drivers drivers = new Drivers();
	assertNotNull(drivers);
	Drivers drivers4 = new Drivers(11,21,1,"car");
	assertEquals(11,drivers4.getDriverID());
	assertEquals(21,drivers4.getTripID());
	assertEquals(1,drivers4.getVehicleID());
	assertEquals("car",drivers4.getType());
}

}
