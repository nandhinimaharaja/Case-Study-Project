package com.java.transport;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Passengers;

public class PassengersTest {
	
@Test

public void testToString() throws ParseException{
	Passengers passengers1 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	String result = "Passengers [passengerID=1, FirstName=Nandhini, gender=female, age=21,email=nandhu@gmail.com,phonenumber=12334455]";
	assertEquals(result, passengers1.toString());
	
}

@Test

public void testEquals() throws ParseException{
	Passengers passengers1 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	Passengers passengers2 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	Passengers passengers3 = new Passengers(11, "Nandhini", "female", 18,"nandhu@gmail.com","12334455");
	assertTrue(passengers1.equals(passengers2));
	assertFalse(passengers1.equals(passengers3));
	
}

@Test

public void testHashCode() throws ParseException{
	Passengers passengers1 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	Passengers passengers2 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	assertEquals(passengers1.hashCode(),passengers2.hashCode());
}
@Test

public void testGettersAndSetters() throws ParseException{
	Passengers passengers = new Passengers();
	passengers.setPassengerID(1);
	passengers.setFirstName("Nandhini");
	passengers.setGender("female");
	passengers.setAge(21);
	passengers.setEmail("nandhu@gmail.com");
	passengers.setPhonenumber("12334455");
	assertEquals(1,passengers.getPassengerID());
	assertEquals("Nandhini",passengers.getFirstName());
	assertEquals("female",passengers.getGender());
	assertEquals(21,passengers.getAge());
	assertEquals("nandhu@gmail.com",passengers.getEmail());
	assertEquals("12334455",passengers.getPhonenumber());
}
@Test

public void testConstructors() throws ParseException{
	Passengers passengers = new Passengers();
    assertNotNull(passengers);
    assertEquals(0, passengers.getPassengerID()); // Default value for int
    assertNull(passengers.getFirstName()); // Default value for String
    assertNull(passengers.getGender()); // Default value for String
    assertEquals(0, passengers.getAge()); // Default value for int
    assertNull(passengers.getEmail()); // Default value for String
    assertNull(passengers.getPhonenumber()); // Default value for String
	
	
	Passengers passengers4 = new Passengers(1, "Nandhini", "female", 21,"nandhu@gmail.com","12334455");
	assertEquals(1,passengers4.getPassengerID());
	assertEquals("Nandhini",passengers4.getFirstName());
	assertEquals("female",passengers4.getGender());
	assertEquals(21,passengers4.getAge());
	assertEquals("nandhu@gmail.com",passengers4.getEmail());
	assertEquals("12334455",passengers4.getPhonenumber());
}

}
