package com.java.transport;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Routes;

public class RoutesTest {
	
@Test

public void testToString() throws ParseException{
	Routes routes1 = new Routes(1, "Kerala", "Chennai", 649.7);
	String result ="Routes [routeID=1, startdestination=Kerala, enddestination=Chennai, distance=649.7]";
	assertEquals(result, routes1.toString());
	
}

@Test

public void testEquals() throws ParseException{
	Routes routes1 = new Routes(1,"Kerala","Chennai",649.70);
	Routes routes2 = new Routes(1,"Kerala","Chennai",649.70);
	Routes routes3 = new Routes(2,"Kerala","Chennai",650.00);
	assertTrue(routes1.equals(routes2));
	assertFalse(routes1.equals(routes3));
	
}

@Test

public void testHashCode() throws ParseException{
	Routes routes1 = new Routes(1,"Kerala","Chennai",649.70);
	Routes routes2 = new Routes(1,"Kerala","Chennai",649.70);
	assertEquals(routes1.hashCode(),routes2.hashCode());
}
@Test

public void testGettersAndSetters() throws ParseException{
	Routes routes = new Routes();
	routes.setRouteID(1);
	routes.setStartdestination("Kerala");
	routes.setEnddestination("Chennai");
	routes.setDistance(649.70);
	assertEquals(1,routes.getRouteID());
	assertEquals("Kerala",routes.getStartdestination());
	assertEquals("Chennai",routes.getEnddestination());
	assertEquals(649.70,routes.getDistance(),0.001);
}
@Test

public void testConstructors() throws ParseException{
	Routes routes = new Routes();
	assertNotNull(routes);
	Routes routes4 = new Routes(1,"Kerala","Chennai",649.70);
	assertEquals(1,routes4.getRouteID());
	assertEquals("Kerala",routes4.getStartdestination());
	assertEquals("Chennai",routes4.getEnddestination());
	assertEquals(649.70,routes4.getDistance(),0.001);
}

}
