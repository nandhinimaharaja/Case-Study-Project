package com.java.transport;

import static org.junit.Assert.*;

import java.sql.Date;
import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Trips;

public class TripsTest {

    @Test
    public void testToString() throws ParseException {
        Trips trips1 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        String result = "Trips [tripID=11, vehicleID=11, routeID=11, depaturedate=2024-09-02, arrivaldate=2024-09-03, status=arrival, tripType=bus, maxpassengers=50]";
        assertEquals(result, trips1.toString());
    }

    @Test
    public void testEquals() throws ParseException {
        Trips trips1 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        Trips trips2 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        Trips trips3 = new Trips(12, 12, 12, Date.valueOf("2024-09-04"), Date.valueOf("2024-09-05"), "departure", "car", 30);
        assertTrue(trips1.equals(trips2));
        assertFalse(trips1.equals(trips3));
    }

    @Test
    public void testHashCode() throws ParseException {
        Trips trips1 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        Trips trips2 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        assertEquals(trips1.hashCode(), trips2.hashCode());
    }

    @Test
    public void testGettersAndSetters() throws ParseException {
        Trips trips = new Trips();
        trips.setTripID(11);
        trips.setVehicleID(11);
        trips.setRouteID(11);
        trips.setDepaturedate(Date.valueOf("2024-09-02"));
        trips.setArrivaldate(Date.valueOf("2024-09-03"));
        trips.setStatus("arrival");
        trips.setTripType("bus");
        trips.setMaxpassengers(50);
        assertEquals(11, trips.getTripID());
        assertEquals(11, trips.getVehicleID());
        assertEquals(11, trips.getRouteID());
        assertEquals(Date.valueOf("2024-09-02"), trips.getDepaturedate());
        assertEquals(Date.valueOf("2024-09-03"), trips.getArrivaldate());
        assertEquals("arrival", trips.getStatus());
        assertEquals("bus", trips.getTripType());
        assertEquals(50, trips.getMaxpassengers());
    }

    @Test
    public void testConstructors() throws ParseException {
        Trips trips = new Trips();
        assertNotNull(trips);
        assertEquals(0, trips.getTripID()); // Default value for int
        assertEquals(0, trips.getVehicleID()); // Default value for int
        assertEquals(0, trips.getRouteID()); // Default value for int
        assertNull(trips.getDepaturedate()); // Default value for Date
        assertNull(trips.getArrivaldate()); // Default value for Date
        assertNull(trips.getStatus()); // Default value for String
        assertNull(trips.getTripType()); // Default value for String
        assertEquals(0, trips.getMaxpassengers()); // Default value for int

        Trips trips4 = new Trips(11, 11, 11, Date.valueOf("2024-09-02"), Date.valueOf("2024-09-03"), "arrival", "bus", 50);
        assertEquals(11, trips4.getTripID());
        assertEquals(11, trips4.getVehicleID());
        assertEquals(11, trips4.getRouteID());
        assertEquals(Date.valueOf("2024-09-02"), trips4.getDepaturedate());
        assertEquals(Date.valueOf("2024-09-03"), trips4.getArrivaldate());
        assertEquals("arrival", trips4.getStatus());
        assertEquals("bus", trips4.getTripType());
        assertEquals(50, trips4.getMaxpassengers());
    }
}
