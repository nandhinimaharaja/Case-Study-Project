package com.java.transport;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

import com.java.transport.model.Vehicles;

public class VehiclesTest {
	
@Test

public void testToString() throws ParseException{
	Vehicles vehicles1 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	String result = "Vehicles [vehicleID=1, model=MrM Travels, capacity=150.00, type=bus,status=available]";
	assertEquals(result, vehicles1.toString());
	
}

@Test

public void testEquals() throws ParseException{
	Vehicles vehicles1 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	Vehicles vehicles2 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	Vehicles vehicles3 = new Vehicles(2, "MrM Travels", 150.00, "car", "available");
	assertTrue(vehicles1.equals(vehicles2));
	assertFalse(vehicles1.equals(vehicles3));
	
}

@Test

public void testHashCode() throws ParseException{
	Vehicles vehicles1 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	Vehicles vehicles2 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	assertEquals(vehicles1.hashCode(),vehicles2.hashCode());
}
@Test

public void testGettersAndSetters() throws ParseException{
	Vehicles vehicles = new Vehicles();
	vehicles.setVehicleID(1);
	vehicles.setModel("MrM Travels");
	vehicles.setCapacity(150.00);
	vehicles.setType("bus");
	vehicles.setStatus("available");
	assertEquals(1,vehicles.getVehicleID());
	assertEquals("MrM Travels",vehicles.getModel());
	assertEquals(150.00,vehicles.getCapacity(),0.001);
	assertEquals("bus",vehicles.getType());
	assertEquals("available",vehicles.getStatus());
}
@Test

public void testConstructors() throws ParseException{
	Vehicles vehicles = new Vehicles();
    assertNotNull(vehicles);
    assertEquals(0, vehicles.getVehicleID()); // Default value for int
    assertNull(vehicles.getModel()); // Default value for String
    assertEquals(0, vehicles.getCapacity(),0.001); // Default value for int
    assertNull(vehicles.getType()); // Default value for String
    assertNull(vehicles.getStatus()); // Default value for String
	
	
	Vehicles vehicles4 = new Vehicles(1, "MrM Travels", 150.00, "bus", "available");
	assertEquals(1,vehicles4.getVehicleID());
	assertEquals("MrM Travels",vehicles4.getModel());
	assertEquals(150.00,vehicles4.getCapacity(),0.001);
	assertEquals("bus",vehicles4.getType());
	assertEquals("available",vehicles4.getStatus());
}

}
